'use strict';

/*
 * Local harness that runs the SAME express app Vercel uses (api/index.js),
 * so the serverless behaviour (routing, CORS) can be validated end-to-end
 * before deploying. Not used in production.
 */

const handler = require('./api/index');

const port = process.env.PORT || 7001;
const server = handler.listen(port, () => {
  console.log(`Vercel-style handler listening on http://localhost:${port}/manifest.json`);
});

process.on('SIGTERM', () => server.close());
