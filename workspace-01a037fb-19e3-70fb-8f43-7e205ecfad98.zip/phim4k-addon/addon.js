'use strict';

/*
 * Shared addon definition (manifest + resource handlers).
 *
 * This module is platform-agnostic:
 *   - server.js uses it with the SDK's serveHTTP() for local dev / containers.
 *   - api/index.js uses it with the SDK's getRouter() to run on Vercel.
 */

const { addonBuilder } = require('stremio-addon-sdk');
const p4k = require('./lib/phim4k.js');

// ---------------------------------------------------------------------------
// Small helpers
// ---------------------------------------------------------------------------

// Simple TTL cache for the slow token resolution + upstream API calls.
const cache = new Map();
function cacheGet(key) {
  const e = cache.get(key);
  if (!e) return undefined;
  if (e.exp < Date.now()) { cache.delete(key); return undefined; }
  return e.val;
}
function cacheSet(key, val, ttlMs) {
  cache.set(key, { val, exp: Date.now() + ttlMs });
  if (cache.size > 500) {
    const now = Date.now();
    for (const [k, v] of cache) if (v.exp < now) cache.delete(k);
  }
}

const TTL_API = 5 * 60 * 1000;        // 5 min  (catalog)
const TTL_META = 15 * 60 * 1000;      // 15 min (metadata)
const TTL_STREAM = 30 * 60 * 1000;    // 30 min (resolved signed CDN URL)

function cleanLabel(label) {
  if (!label) return 'Phim4K';
  const size = /\(([^)]*)\)/.exec(label);
  const qua = /^(\d{3,4}[PSK])/.exec(label.trim());
  let out = '';
  if (qua) out += qua[1].toUpperCase();
  if (size) out += (out ? ' • ' : '') + size[1].trim();
  return out || label;
}

function parseSxxEyy(name) {
  const m = /^S?(\d+)\s*E(\d+)/i.exec((name || '').trim());
  return m ? { season: parseInt(m[1], 10), episode: parseInt(m[2], 10) } : null;
}

function yearOf(release) {
  const m = /(\d{4})/.exec(String(release || ''));
  return m ? parseInt(m[1], 10) : undefined;
}

function num(v) { const n = parseFloat(v); return isNaN(n) ? undefined : n; }

// Map one item returned by list endpoints (movies / tvseries / search) -> Preview.
// The catalog `type` is authoritative; `is_tvseries` is a fallback/override.
function mapPreview(m, defaultType) {
  const isSeries =
    String(m.is_tvseries) === '1' || m.is_tvseries === 1 ||
    !!(m.type && String(m.type) === 'tvseries') ||
    (defaultType === 'series' || (defaultType && String(defaultType).toLowerCase() === 'series'));
  return {
    id: String(m.videos_id === undefined ? m.id : m.videos_id),
    type: isSeries ? 'series' : 'movie',
    name: m.title,
    poster: m.poster_url || m.thumbnail_url,
    background: m.thumbnail_url || m.poster_url,
    description: m.description,
    releaseInfo: m.release,
    runtime: m.runtime ? String(m.runtime).replace(/\s*min$/i, '').trim() : undefined,
    imdbRating: num(m.imdb_rating),
    year: yearOf(m.release),
  };
}

// ---------------------------------------------------------------------------
// Upstream fetchers (with a bit of caching + graceful fallback)
// ---------------------------------------------------------------------------

async function getList(path, params) {
  const key = 'list:' + path + ':' + JSON.stringify(params);
  const hit = cacheGet(key);
  if (hit) return hit;
  const data = await p4k.apiGet(path, params);
  cacheSet(key, data, TTL_API);
  return data;
}

async function getDetail(type, id) {
  const key = 'detail:' + type + ':' + id;
  const hit = cacheGet(key);
  if (hit) return hit;
  const data = await p4k.apiGet('single_details', { type, id });
  cacheSet(key, data, TTL_META);
  return data;
}

async function resolveCached(fileUrl) {
  const filename = String(fileUrl || '').trim().split('/').pop().split('?')[0];
  if (!filename) return undefined;
  const key = 'res:' + filename;
  const hit = cacheGet(key);
  if (hit) return hit;
  const url = await p4k.resolveStream(fileUrl);
  cacheSet(key, url, TTL_STREAM);
  return url;
}

// Build a Stremio stream entry from a resolved URL + subtitle list
function makeStream(url, title, subtitle) {
  const stream = {
    name: 'Phim4K',
    title: title || 'Phim4K',
    url: url,
    behaviorHints: { proxyHeaders: false, notWebReady: false },
  };
  if (Array.isArray(subtitle) && subtitle.length) {
    stream.subtitles = subtitle
      .filter((s) => s && s.url)
      .map((s) => ({ lang: s.srclang || s.language || 'vi', url: s.url }));
  }
  return stream;
}

// ---------------------------------------------------------------------------
// Manifest
// ---------------------------------------------------------------------------

const manifest = {
  id: 'com.arena.phim4k',
  name: 'Phim4K',
  description:
    'Addon for the Phim4K Vietnamese movie / TV app (com.files.codes). ' +
    'Sources are requested live from the Phim4K API and the token-protected CDN.',
  version: '0.0.2',
  resources: ['catalog', 'meta', 'stream'],
  types: ['movie', 'series'],
  // NOTE: we advertise search/skip via the LONG `extra` array form
  // ( [{ name, isRequired, ... }] ), NOT the short `extraSupported` shorthand.
  // The short form is part of the older protocol spec and several third-party
  // Stremio clients (notably Nuvio) don't parse it, so they report
  // "your installed addons do not expose catalog search".
  catalogs: [
    {
      type: 'movie', id: 'phim4k-new', name: 'Phim4K • Phim Mới',
      extra: [
        { name: 'search', isRequired: false },
        { name: 'skip',   isRequired: false },
      ],
    },
    {
      type: 'series', id: 'phim4k-new', name: 'Phim4K • Phim Bộ Mới',
      extra: [
        { name: 'search', isRequired: false },
        { name: 'skip',   isRequired: false },
      ],
    },
    {
      type: 'movie', id: 'phim4k-top', name: 'Phim4K • Top Phim',
      extra: [ { name: 'skip', isRequired: false } ],
    },
    {
      type: 'series', id: 'phim4k-top', name: 'Phim4K • Top Phim Bộ',
      extra: [ { name: 'skip', isRequired: false } ],
    },
  ],
  behaviorHints: { configurable: false },
};

const builder = new addonBuilder(manifest);

// ---------------------------------------------------------------------------
// Catalog handler
// ---------------------------------------------------------------------------

builder.defineCatalogHandler(async (args) => {
  const { type, id, extra = {} } = args;
  const page = Math.floor((extra.skip || 0) / 20) + 1;
  const limit = 20;
  let list = [];

  try {
    if (extra.search) {
      const q = String(extra.search).trim();
      if (q.length < 3) return { metas: [] };
      const apiType = type === 'movie' ? 'movie' : 'tvseries';
      const res = await getList('search', { q, page, type: apiType });
      list = (apiType === 'movie' ? (res.movie || []) : (res.tvseries || []));
    } else if (id === 'phim4k-top') {
      const apiType = type === 'movie' ? 'movie' : 'tvseries';
      list = await getList('top_views', { period: 'week', type: apiType, limit, page });
    } else if (type === 'movie') {
      list = await getList('movies', { page, limit });
    } else {
      list = await getList('tvseries', { page, limit });
    }
  } catch (e) {
    console.error('[catalog]', type, id, extra, e.message);
    list = [];
  }

  const metas = (Array.isArray(list) ? list : [])
    .map((m) => mapPreview(m, type))
    .filter((m) => m.id && m.name);
  return { metas };
});

// ---------------------------------------------------------------------------
// Meta handler
// ---------------------------------------------------------------------------

builder.defineMetaHandler(async (args) => {
  const { type, id } = args;
  const apiType = type === 'movie' ? 'movie' : 'tvseries';
  let d;
  try {
    d = await getDetail(apiType, id);
  } catch (e) {
    console.error('[meta]', type, id, e.message);
    return { meta: { id, type, name: id } };
  }

  const isSeries = String(d.is_tvseries) === '1' || type === 'series';
  const genres = (d.genre || []).map((g) => g.name).filter(Boolean);
  const cast = (d.cast || []).map((c) => (typeof c === 'string' ? c : c.name)).filter(Boolean);
  const director = (d.director || []).map((c) => (typeof c === 'string' ? c : c.name)).filter(Boolean);

  const meta = {
    id: String(id),
    type: isSeries ? 'series' : 'movie',
    name: d.title,
    poster: d.poster_url || d.thumbnail_url,
    background: d.thumbnail_url || d.poster_url,
    description: d.description,
    releaseInfo: d.release,
    runtime: d.runtime ? String(d.runtime).replace(/\s*min$/i, '').trim() : undefined,
    imdbRating: num(d.imdb_rating),
    genres,
    cast: cast.length ? cast : undefined,
    director: director.length ? director : undefined,
    videos: [],
  };

  if (isSeries && Array.isArray(d.season) && d.season.length) {
    // d.season holds "servers" (e.g. 1080p / 2160p). Each server lists the same
    // episodes (S01E01...). Deduplicate by season+episode, keep the freshest name.
    const epMap = new Map();
    for (const server of d.season) {
      for (const ep of (server.episodes || [])) {
        const parsed = parseSxxEyy(ep.episodes_name);
        const season = parsed ? parsed.season : 1;
        const numEp = parsed ? parsed.episode : (parseInt(ep.episodes_id, 10) || ep.episodes_id);
        const key = season + ':' + numEp;
        if (!epMap.has(key)) {
          epMap.set(key, {
            id: `${id}:${season}:${numEp}`,
            name: parsed ? `Tập ${numEp}` : (ep.episodes_name || `Tập ${numEp}`),
            title: ep.episodes_name,
            season,
            number: numEp,
            released: d.release,
          });
        }
      }
    }
    meta.videos = [...epMap.values()].sort((a, b) => a.season - b.season || a.number - b.number);
  } else {
    // Movie: give Stremio one playable video entry (id == meta id)
    meta.videos = [{ id: String(id), title: d.title, released: d.release }];
  }

  return { meta };
});

// ---------------------------------------------------------------------------
// Stream handler
// ---------------------------------------------------------------------------

builder.defineStreamHandler(async (args) => {
  const { type, id } = args;
  const raw = String(id);
  const parts = raw.split(':');
  let metaId = parts[0];
  let season = null;
  let episode = null;
  if (parts.length >= 3) {
    season = parseInt(parts[1], 10);
    episode = parseInt(parts[2], 10);
  }

  const apiType = type === 'movie' ? 'movie' : 'tvseries';
  let streams = [];
  try {
    const d = await getDetail(apiType, metaId);

    if (!episode && (apiType === 'movie' || !Array.isArray(d.season) || !d.season.length)) {
      // Movie (or series detail that exposes videos directly)
      for (const v of (d.videos || [])) {
        if (!v.file_url) continue;
        const url = await resolveCached(v.file_url);
        if (!url) continue;
        streams.push(makeStream(url, cleanLabel(v.label), v.subtitle));
      }
    } else {
      // Series: find the matching episode across all "server" qualities
      for (const server of (d.season || [])) {
        for (const ep of (server.episodes || [])) {
          const parsed = parseSxxEyy(ep.episodes_name);
          const sNum = parsed ? parsed.season : 1;
          const eNum = parsed ? parsed.episode : (parseInt(ep.episodes_id, 10) || ep.episodes_id);
          if (season !== null && episode !== null && (sNum !== season || eNum !== episode)) continue;
          if (season === null && episode === null && d.season.length > 1) continue; // avoid dumping every episode
          const url = await resolveCached(ep.file_url);
          if (!url) continue;
          const qual = server.seasons_name || 'Phim4K';
          streams.push(makeStream(url, `${qual} • ${parsed ? `Tập ${eNum}` : ep.episodes_name}`, ep.subtitle));
        }
      }
    }
  } catch (e) {
    console.error('[stream]', raw, e.message);
    streams = [];
  }

  return { streams };
});

// ---------------------------------------------------------------------------
// Exports
// ---------------------------------------------------------------------------

module.exports = { manifest, getInterface: () => builder.getInterface() };
