# Phim4K — Stremio Addon

A [Stremio](https://www.stremio.com) addon that fetches movie / TV sources from the
**Phim4K** Android TV app that AFTVnews short link `https://aftv.news/3621883` points to
(`phim4k-2.6.6-cho-tivi.apk`, package `com.files.codes`).

This addon was produced by **reverse-engineering the APK** (see below), not by any public API.

---

## What the app is

The short link redirects to a Dropbox-hosted APK:

```
https://aftv.news/3621883  ->  phim4k-2.6.6-cho-tivi.apk
```

UI language is Vietnamese. It's a Netflix-style streaming client with movies, TV series and live TV.

---

## How the API was found

1. Downloaded the APK and extracted it (`unzip`).
2. Decompiled it with **jadx** → readable Java under `sources/`.
3. Key classes:

   | Class | Purpose |
   |---|---|
   | `com.files.codes.model.api.ApiService` | Retrofit REST API (movies/search/detail/favorites/…) |
   | `com.files.codes.utils.DynamicConfig` | Hosts + API key, decrypted remotely each run |
   | `com.files.codes.utils.RetrofitClient` | main client (`v130/` + Basic auth) |
   | `com.files.codes.utils.Phim4kClient` / `KKPhim4kClient` | secondary OPhim-style sources |
   | `com.files.codes.utils.VideoTokenGenerator` | builds the **signed** CDN stream URL |
   | `com.files.codes.AppConfig` | native (`libapi_config.so`) getters for api url / api key |

4. The API hosts are pushed from a remote config worker, so the *static* defaults in the binary
   (`*.phim4k.online`, `*.phim4k.lol`) are dead. The current live value is fetched from
   `https://ltv.cryboiz.workers.dev/api/add` and decrypted (AES-256-GCM, key = `SHA-256("8zP2mN7xR4vW9bQ1eC5yU0sI6tO3pA4f")`).

### Live API (recovered)

* **Base** : `https://apip4k.dpdns.org/rest-api/v130`
* **Header**: `API-KEY: bbb411dea44849`

| Endpoint | Params | Returns |
|---|---|---|
| `GET /movies` | `page`, `limit` | array of movies |
| `GET /tvseries` | `page`, `limit` | array of series |
| `GET /top_views` | `period`, `type`, `limit`, `page` | array |
| `GET /latest_movies` | `limit`, `page` | array |
| `GET /search` | `q`, `page`, `type` (`movie`/`tvseries`) | `{movie, tvseries, tv_channels}` |
| `GET /single_details` | `type`, `id` | full detail + `videos[]` / `season[]` + `subtitle[]` |
| `GET /home_content_for_android` | — | home screen content |
| `GET /all_genre`, `/all_country` | — | filters |

**Item shape**

```jsonc
{
  "videos_id": "17758",
  "title": "Ngôi Đền Kỳ Quái 5 (2026) Pee Nak 5",
  "slug": "ngoi-den-ky-quai-5",
  "type": "movie",
  "release": "2026",
  "runtime": "118 Min",
  "video_quality": "4K (PĐ)",
  "is_tvseries": "0",
  "imdb_rating": "8.5",
  "thumbnail_url": "https://apip4k.dpdns.org/uploads/video_thumb/17758.jpg",
  "poster_url":  "https://apip4k.dpdns.org/uploads/poster_image/17758.jpg"
}
```

**Detail shape**

```jsonc
{
  "videos_id": "17758",
  "title": "...",
  "is_tvseries": "0",
  "videos": [                       // movie: one entry per quality
    { "video_file_id":"34581", "label":"1080P....(4.63 GB)", "file_type":"mkv",
      "file_url":"https://cdn.phim4k.lol/3F7OOQ8YUBOYOG5Y", "subtitle":[] },
    { "video_file_id":"34582", "file_type":"mkv",
      "file_url":"https://cdn.phim4k.lol/HFEIZ8UBPELI",
      "subtitle":[ { "url":"https://apip4k.dpdns.org/uploads/subtitles/17758_34582_...vtt", "srclang":"vi" } ] }
  ],
  "genre": [ {"name":"Phim Kinh Dị"} ],
  "season": [                        // series: one entry per quality ("server")
    { "seasons_name":"1080p", "episodes":[ {"episodes_id":"182729","episodes_name":"S01E01....mkv",
        "file_type":"mkv","file_url":"https://cdn.phim4k.lol/WGD4AQLIIR1L","subtitle":[]} ] }
  ]
}
```

### The stream URL is signed

`file_url` points at `cdn.phim4k.lol` which **no longer resolves**. The app calls
`VideoTokenGenerator.resolveStreamUrlAsync()` which:

1. re-hosts the filename on the current CDN `sv1.p4k.dpdns.org`,
2. appends a **HMAC-SHA256 token** plus an XOR-obfuscated timestamp, and
3. fetches that URL → returns `{"url":"https://<real-cdn>/<file>...","expires_in":21600}`.

That real URL is what the player uses. All of it is re-implemented in [`lib/phim4k.js`](lib/phim4k.js).

**Recovered constants** (from `libapi_config.so` strings — XOR `0x37`/`0x5a`):

```js
HMAC_SECRET = "5e8d1b4f9c2a6e730b1f8d4a92c5e3d1"   // nativeGetHmacSecret2, XOR 0x5a
API_KEY     = "bbbb411dea44849"                    // AppConfig.getApiKey
API_BASE    = "https://apip4k.dpdns.org/rest-api/v130"
CDN_HOST    = "sv1.p4k.dpdns.org"
```

The token algorithm (ported to Node):

```
daily = yyyyMMdd(UTC)
key   = SHA256(secret)
iv    = SHA256("iv:"+secret)[0:12]
ct    = AES-256-GCM(key, iv, secret+":"+daily)          # tag appended
sign  = secret + ":" + hex(ct)
ts    = unix_seconds
token = HMAC-SHA256(sign, filename+":"+ts)
ts    = hex( int32be(ts) ^ HMAC-SHA256(sign,"otp-ts-mask")[0:4] )
url   = https://CDN/filename?token=token&ts=ts
```

> **Note — byte order matters.** Java's `ByteBuffer.putInt().array()` is big-endian.
> Using little-endian silently routes to a **demo proxy** (`*.up.railway.app` serving a
> fixed 1.3 MB `demo.mp4`). The addon uses big-endian, which resolves to the real files.

---

## Run the addon

```bash
cd phim4k-addon
npm install        # installs stremio-addon-sdk
npm start          # serves on http://localhost:7000
```

Then in Stremio go to *Addons → Community / URL* and add:

```
http://localhost:7000/manifest.json
```

Or use the hosted URL from the live preview if the server is being served remotely.

### Endpoints

* `GET /manifest.json` — addon manifest
* `GET /catalog/movie/phim4k-new.json`
* `GET /catalog/series/phim4k-new/search=gto.json`
* `GET /meta/movie/{id}.json`
* `GET /stream/movie/{id}.json`
* `GET /stream/series/{metaId}:{season}:{episode}.json`

---

## Deploy to Vercel (serverless)

The addon ships with a Vercel entry point. `api/index.js` wraps the Stremio router
in an Express app and exports it as a serverless function; `vercel.json` rewrites all
paths into that function (so `/manifest.json`, `/catalog/...`, `/stream/...` all work)
and bumps the function timeout to 60 s.

```
api/index.js      # serverless handler (Express + getRouter)
vercel.json       # rewrite all -> /api, maxDuration 60
addon.js          # shared manifest + resource handlers (used by both server.js and api/index.js)
```

### Option A — CLI (fastest)

```bash
cd phim4k-addon
npm i -g vercel
vercel          # first run: login + link repo; answer "no" to tweaks; defaults are fine
vercel --prod   # deploy to production
```

The CLI prints the production URL, e.g. `https://phim4k-xxx.vercel.app`.

### Option B — Git integration (auto-deploy on push)

1. Push this folder to a GitHub repo.
2. In [Vercel](https://vercel.com/new) → *Import Git Repository* → select the repo.
3. Vercel auto-detects the Node project; keep defaults (no build command needed).
4. Deploy. Every push re-deploys.

### Install the addon in Stremio

Add the deployed `/manifest.json` URL in Stremio via **Addons → Community / URL**:

```
https://<your-project>.vercel.app/manifest.json
```

The CLI / Git flow is tested locally via `npm run test:vercel` (runs the same Express
handler on port 7001 that Vercel executes).

> **Tip:** Vercel caches the addon responses. If you tweak code, redeploy and hard-refresh
> Stremio (or re-add the addon) to pick up the new manifest/catalogs.

---

## Project layout

```
phim4k-addon/
├── server.js         # local / container dev server (serveHTTP)
├── api/index.js      # Vercel serverless handler (getRouter + express)
├── addon.js          # shared manifest + catalog/meta/stream handlers
├── lib/phim4k.js     # API client + signed-stream token generator (recovered crypto)
├── vercel.json       # Vercel routing + timeout
└── package.json
```

## Searching in Nuvio (and other Stremio clients)

If Nuvio shows **"your installed addons do not expose catalog search"**, the addon's
manifest wasn't advertising search in a form that client recognises. Search is exposed
per-catalog through an `extra` array:

```json
"extra": [ { "name": "search", "isRequired": false }, { "name": "skip", "isRequired": false } ]
```

This is the **long** form. The older short shorthand (`"extraSupported": ["search"]`) is
valid in the spec but isn't parsed by every third-party client — Nuvio among them — so we
use the long form (see `manifest` in `addon.js`). The version is bumped to `0.0.2` so
clients re-fetch the manifest. After deploying, **remove and re-add** the addon (or
reinstall the URL) so Nuvio picks up the change.

The search route then responds to `/catalog/{type}/{id}/search={query}.json` — e.g.
`/catalog/movie/phim4k-new/search=phantom.json`.

---

## Caveats / notes

* The addon **needs network access** to call the Phim4K API and resolve signed stream URLs.
* The upstream API is third-party and unofficially documented; endpoints can change.
* The resolved stream URLs are time-limited; the addon regenerates them on demand
  (30 min memory cache).
* Subtitles (`.vtt`) returned by the API are exposed to Stremio.
* This was done for interoperability/educational purposes — respect the app's terms.
