'use strict';

/*
 * Local / container development server for the Phim4K Stremio addon.
 *
 *   npm start   ->   http://localhost:7000/manifest.json
 *
 * For production on Vercel, see api/index.js (serverless).
 */

const { serveHTTP } = require('stremio-addon-sdk');
const { getInterface } = require('./addon');

const port = process.env.PORT || 7000;

serveHTTP(getInterface(), { port })
  .then((res) => {
    console.log('Phim4K addon serving on', res.url);
  })
  .catch((e) => {
    console.error('Failed to start server:', e.message);
    process.exit(1);
  });
