'use strict';

/*
 * Vercel serverless entry point.
 *
 * Vercel invokes this handler for every request routed to /api (see vercel.json),
 * with the original URL preserved in req.url, so the Stremio resource routes
 * (/manifest.json, /catalog/..., /meta/..., /stream/...) are served as-is.
 */

const express = require('express');
const { getRouter } = require('stremio-addon-sdk');
const { getInterface } = require('../addon');

const app = express();

// Small convenience routes so the bare site never hangs.
app.get('/', (req, res) => res.redirect('/manifest.json'));
app.get('/health', (req, res) => res.json({ status: 'ok', addon: getInterface().manifest.name }));
app.get('/favicon.ico', (req, res) => res.status(204).end());

// The SDK router handles CORS *and* the addon protocol routes.
app.use(getRouter(getInterface()));

module.exports = app;
