# PolyCue

Self-hosted **Stremio / Nuvio subtitle addon**. It searches several providers **in parallel** using **your** API keys, then proxies the file (unzip, encoding, ASS/VTT → SRT) so every client can play it.

Providers (enable any mix):

| Provider | Key | Where to get it |
|---|---|---|
| [OpenSubtitles.com](https://www.opensubtitles.com) | API key + optional username/password | [Create a consumer](https://www.opensubtitles.com/en/consumers) |
| [SubDL](https://subdl.com) | API key | [subdl.com/panel/api](https://subdl.com/panel/api) |
| [SubSource](https://subsource.net) | API key | Profile → API key |
| [Wyzie](https://sub.wyzie.io) | API key | [store.wyzie.io/redeem](https://store.wyzie.io/redeem) |

Nuvio speaks the same addon protocol as Stremio, so one manifest URL works in both.

---

## Deploy on Vercel

1. Push this folder to a GitHub repo (or `npx vercel` from the folder).
2. In [vercel.com](https://vercel.com) → **Add New** → **Project** → import the repo.
3. Framework Preset: **Other**. Root directory: this folder.
4. (Recommended) add environment variables so keys never sit in the install URL:

```
OPENSUBTITLES_API_KEY=
OPENSUBTITLES_USERNAME=
OPENSUBTITLES_PASSWORD=
OPENSUBTITLES_USER_AGENT=PolyCue v1.0.0
SUBDL_API_KEY=
SUBSOURCE_API_KEY=
WYZIE_API_KEY=
CONFIG_SECRET=          # optional; encrypts keys inside the manifest URL
```

`CONFIG_SECRET` can be any long random string:

```bash
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

5. Deploy. Open `https://YOUR-PROJECT.vercel.app/configure`.

### OpenSubtitles User-Agent

OpenSubtitles requires a **registered** User-Agent that matches the consumer name you created. Either:

- Register an app named **PolyCue v1.0.0**, or
- Put your own consumer name in `OPENSUBTITLES_USER_AGENT` / the configure form.

Username + password are optional for search, but needed for a decent daily download quota.

---

## Install

### Stremio

1. Open the configure page.
2. Paste keys (or leave blank if you set Vercel env vars).
3. Pick languages.
4. **Install in Stremio**.

Or paste this after configuring:

```
https://YOUR-PROJECT.vercel.app/<token>/manifest.json
```

If keys live only in Vercel env, you can install the unscoped URL:

```
https://YOUR-PROJECT.vercel.app/manifest.json
```

### Nuvio

1. Click **Copy manifest URL for Nuvio** on the configure page.
2. Nuvio → **Settings** → **Addons** → **Add Addon** → paste the URL → Install.

---

## Run locally

```bash
npm install
cp .env.example .env   # optional
npm start
```

Then open [http://127.0.0.1:7000/configure](http://127.0.0.1:7000/configure).

---

## How it works

```
Stremio/Nuvio
    → GET /{config}/subtitles/movie/tt1375666.json
    → PolyCue queries every provider you keyed, in parallel
    → returns a list of { id, url, lang }

Player picks a row
    → GET /{config}/dl/sd/123-456.srt
    → PolyCue downloads (ZIP if needed), extracts the right episode,
      fixes encoding, converts ASS/VTT → SRT
```

`{config}` is a compact token (optionally AES-GCM encrypted). The addon does **not** keep a database of your keys.

---

## Protocol routes

| Route | Purpose |
|---|---|
| `/configure` | Key + language UI |
| `/manifest.json` | Unscoped manifest (env keys) |
| `/:token/manifest.json` | Configured manifest |
| `/:token/subtitles/:type/:id.json` | Search |
| `/:token/dl/:provider/:file.srt` | Download proxy |
| `/health` | Liveness |

---

## Notes

- Personal / self-hosted use. Stay inside each provider’s rate limits.
- Keys placed in the configure form become part of the install URL. Prefer Vercel env vars.
- Hash-matched OpenSubtitles results are ranked first when Stremio sends `videoHash`.
