'use strict';

const http = require('http');
const app = require('./lib/app');

const port = Number(process.env.PORT) || 7000;
http.createServer(app).listen(port, '0.0.0.0', () => {
  console.log(`PolyCue listening on http://0.0.0.0:${port}`);
  console.log(`Configure: http://127.0.0.1:${port}/configure`);
});
